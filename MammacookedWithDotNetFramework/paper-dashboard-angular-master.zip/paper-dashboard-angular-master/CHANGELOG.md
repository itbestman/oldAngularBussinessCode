## [2.0.0] 2019-17-07
### Updates
- update from Bootstrap 3 to Bootstrap 4
- update to Angular 8
- update all dependencies to match Angular 8 version
- change the product structure
### Added
- useHash
- online doc
- paper 2 styles
- fixed plugin
- copyright
- issue_template
### Bug Fixing
- fix sidebar scroll

## [1.0.1] 2017-12-07
- fixed errors for npm start

## [1.0.0] 2017-06-27
### Initial Release
